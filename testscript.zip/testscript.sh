#! /bin/bash

while (true); do
    ./test1
done